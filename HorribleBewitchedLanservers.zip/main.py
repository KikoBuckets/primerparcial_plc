# Solicitar al usuario el precio original y el cupón de descuento en porcentaje
precio_original = float(input("Ingrese el precio original de la comida: "))
cupon_descuento = float(input("Ingrese el cupón de descuento en porcentaje: "))

# Calcular el precio final y el ahorro en dinero
descuento = precio_original * (cupon_descuento / 100)
precio_final = precio_original - descuento

# Mostrar el precio final y el ahorro en dinero
print(f"Precio final después del descuento: {precio_final:.2f}")
print(f"Ahorro en dinero: {descuento:.2f}")
