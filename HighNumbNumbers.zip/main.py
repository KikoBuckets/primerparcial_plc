def mult(a,b)
return x

def div(a,b)
return x
print("dame el primer número)
a=int(input())
print("dame el segundo número")
b=int(input())
print("el resultado de la multiplicación es",(a*b))
print("el resultado de división es",(a/b))
