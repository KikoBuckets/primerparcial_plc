# Solicitar al usuario la temperatura en grados Celsius
celsius = float(input("Ingresa la temperatura en grados Celsius: "))

# Realizar la conversión a Fahrenheit y Kelvin
fahrenheit = (celsius * 9/5) + 32
kelvin = celsius + 273.15

# Mostrar los resultados
print(f"{celsius} grados Celsius equivalen a {fahrenheit} grados Fahrenheit.")
print(f"{celsius} grados Celsius equivalen a {kelvin} Kelvin.")
