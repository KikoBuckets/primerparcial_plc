# Solicitar al usuario el costo total de la compra
costo_total = float(input("Ingrese el costo total de la compra: $"))

# Aplicar el descuento del 20%
descuento = 0.20 * costo_total
costo_con_descuento = costo_total - descuento

# Mostrar el costo total con descuento
print(f"El costo total de la compra con el descuento del 20% es: ${costo_con_descuento:.2f}")
