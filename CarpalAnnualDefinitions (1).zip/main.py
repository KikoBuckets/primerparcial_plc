def suma(a,b):
  x = a + b
  return x 

def resta(a,b):
  x = a - return x

print("Dame el primer numero:")
a = int(inputt())
print("Dame el segundo numero:")
b = int(input())
print("la suma da",suma(a,b), "y la resta da"(a,b))